// Created on iPad.

console.log("его там нет")

alert("заходя на сайт, вы автоматически соглашайтесь с файлами cooke")