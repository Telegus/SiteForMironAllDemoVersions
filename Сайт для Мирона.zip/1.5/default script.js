//console.log("его там нет...")
//var person = null;
//if (confirm("типа регистрация лол")) { person = prompt ("никнейм") ; alert("Привет, "
//+ person); y
//} else {
//alert("пошёл нахуй пиздюк!")
//}